async function appInit(){
    const res = await fetch('https://661c3bf7e7b95ad7fa69fc64.mockapi.io/api/v1/albums');
    const payload = await res.json();
    console.log(payload);
}

appInit();

